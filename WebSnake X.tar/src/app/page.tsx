'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Play, Pause, RotateCcw, Settings, Trophy } from 'lucide-react'
import GameCanvas from '@/components/GameCanvas'
import ScoreDisplay from '@/components/ScoreDisplay'
import ControlButtons from '@/components/ControlButtons'
import SoundToggle from '@/components/SoundToggle'
import { ThemeToggle } from '@/components/ThemeToggle'
import MobileControls from '@/components/MobileControls'

export default function Home() {
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'paused' | 'gameOver'>('idle')
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [gameSettings, setGameSettings] = useState({
    gameSpeed: 'medium' as 'easy' | 'medium' | 'hard',
    gridSize: 'normal' as 'small' | 'normal' | 'large'
  })

  // Load high score from localStorage on mount
  useEffect(() => {
    const savedHighScore = localStorage.getItem('snakeHighScore')
    if (savedHighScore) {
      setHighScore(parseInt(savedHighScore, 10))
    }
    const savedSoundSetting = localStorage.getItem('snakeSoundEnabled')
    if (savedSoundSetting !== null) {
      setSoundEnabled(savedSoundSetting === 'true')
    }
    const savedGameSettings = localStorage.getItem('snakeGameSettings')
    if (savedGameSettings) {
      const parsed = JSON.parse(savedGameSettings)
      setGameSettings(parsed)
      setSoundEnabled(parsed.soundEnabled)
    }
  }, [])

  // Save high score to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('snakeHighScore', highScore.toString())
  }, [highScore])

  // Save sound setting to localStorage
  useEffect(() => {
    localStorage.setItem('snakeSoundEnabled', soundEnabled.toString())
  }, [soundEnabled])

  const handleGameStart = useCallback(() => {
    setGameState('playing')
  }, [])

  const handleGamePause = useCallback(() => {
    setGameState('paused')
  }, [])

  const handleGameResume = useCallback(() => {
    setGameState('playing')
  }, [])

  const handleGameOver = useCallback(() => {
    setGameState('gameOver')
    if (score > highScore) {
      setHighScore(score)
    }
  }, [score, highScore])

  const handleGameRestart = useCallback(() => {
    setScore(0)
    setGameState('playing')
  }, [])

  const handleScoreUpdate = useCallback((newScore: number) => {
    setScore(newScore)
  }, [])

  const handleSoundToggle = useCallback(() => {
    setSoundEnabled(prev => !prev)
  }, [])

  const handleMobileDirectionChange = useCallback((newDirection: 'up' | 'down' | 'left' | 'right') => {
    // This will be passed to the GameCanvas component
    // We'll need to lift this state up or use a ref
    const canvas = document.querySelector('canvas')
    if (canvas) {
      const event = new KeyboardEvent('keydown', {
        key: `Arrow${newDirection.charAt(0).toUpperCase() + newDirection.slice(1)}`
      })
      canvas.dispatchEvent(event)
    }
  }, [])

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-8 p-4 bg-background">
      <div className="w-full max-w-4xl space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-6xl font-bold text-primary">🐍 WebSnake X</h1>
          <p className="text-muted-foreground">A modern Snake Game built with Next.js</p>
        </div>

        {/* Game Stats */}
        <div className="flex justify-center items-center gap-4">
          <ScoreDisplay currentScore={score} highScore={highScore} />
          <Badge variant={gameState === 'playing' ? 'default' : 'secondary'}>
            {gameState === 'idle' && 'Ready to Play'}
            {gameState === 'playing' && 'Playing'}
            {gameState === 'paused' && 'Paused'}
            {gameState === 'gameOver' && 'Game Over'}
          </Badge>
        </div>

        {/* Game Canvas */}
        <Card className="w-full">
          <CardContent className="p-4">
            <GameCanvas
              gameState={gameState}
              onGameStart={handleGameStart}
              onGamePause={handleGamePause}
              onGameResume={handleGameResume}
              onGameOver={handleGameOver}
              onScoreUpdate={handleScoreUpdate}
              soundEnabled={soundEnabled}
              gameSpeed={gameSettings.gameSpeed}
              gridSize={gameSettings.gridSize}
            />
          </CardContent>
        </Card>

        {/* Mobile Controls */}
        <div className="flex justify-center md:hidden">
          <MobileControls
            onDirectionChange={handleMobileDirectionChange}
            disabled={gameState !== 'playing'}
          />
        </div>

        {/* Control Buttons */}
        <div className="flex justify-center gap-4">
          <ControlButtons
            gameState={gameState}
            onStart={handleGameStart}
            onPause={handleGamePause}
            onResume={handleGameResume}
            onRestart={handleGameRestart}
          />
          <SoundToggle
            enabled={soundEnabled}
            onToggle={handleSoundToggle}
          />
          <ThemeToggle />
          <Button
            variant="outline"
            size="icon"
            onClick={() => window.location.href = '/settings'}
          >
            <Settings className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => window.location.href = '/leaderboard'}
          >
            <Trophy className="h-4 w-4" />
          </Button>
        </div>

        {/* Game Instructions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-center">How to Play</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h3 className="font-semibold mb-2">Controls:</h3>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Arrow Keys: Move snake</li>
                  <li>• Spacebar: Pause/Resume</li>
                  <li>• Click buttons: Control game</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Rules:</h3>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Eat food to grow and score</li>
                  <li>• Avoid walls and yourself</li>
                  <li>• Try to beat your high score!</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}